import os
import shutil

os.system('git clone https://github.com/luong-komorebi/Simple-CRUD-Flask-App')
shutil.rmtree('Simple-CRUD-Flask-App')