1. For code use:

<pre class="code" style="background-color: rgb(217,238,239,255);">

int a = 10

</pre>

2. For Large Json text use (to wrap) :

<textarea rows="10" cols="150" readonly>

hello line
hello line 2
</textarea>