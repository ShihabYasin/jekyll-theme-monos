---
layout: page
title: CV/Résumé
permalink: /about/
---


CHECK MAKEFILE FOR HOW TO RUN INSTRUCTIONS.


This is a test site, live edit your post and check your site offline at ```http://127.0.0.1:4000/``` in browser.